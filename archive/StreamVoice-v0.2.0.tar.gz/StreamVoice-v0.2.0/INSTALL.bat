@echo off
color 0A
title StreamVoice Installer

echo ========================================
echo     STREAMVOICE INSTALLER
echo ========================================
echo.

:: Check if Node.js is installed
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Node.js not found!
    echo.
    echo Opening Node.js download page...
    start https://nodejs.org/
    echo.
    echo Please install Node.js first, then run this installer again.
    pause
    exit
)

echo [OK] Node.js found!
echo.
echo Installing StreamVoice dependencies...
cd server
call npm install
cd ..
echo.
echo ========================================
echo     INSTALLATION COMPLETE!
echo ========================================
echo.
echo To start StreamVoice, double-click EASY_TEST.bat
echo.
pause
